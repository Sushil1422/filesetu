// import React, { useState, useEffect } from 'react';
// import { useAuth } from '../contexts/AuthContext';
// import { db, storage, database } from '../firebase'; // Added database import
// import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
// import { ref as dbRef, push } from 'firebase/database'; // Realtime Database imports
// import { v4 as uuidv4 } from 'uuid';
// import { useParams } from 'react-router-dom';  // <-- for getting the id param
// import { get, child } from 'firebase/database';
// // import './FileUpload.css';

// const FileUpload = ({selectedId}) => {
//   console.log("selectedId",selectedId);
  
//   const { currentUser } = useAuth();
//   const { id } = useParams(); // useParams() will give you the id param if present
// const [isEditing, setIsEditing] = useState(false);
// const [initialFileInfo, setInitialFileInfo] = useState(null); // stores existing file info for edit mode

//   const [uploading, setUploading] = useState(false);
//   const [uploadProgress, setUploadProgress] = useState(0);
//   const [formData, setFormData] = useState({
//     department: '',
//     receivedFrom: '',
//     subject: '',
//     allocatedTo: '',
//     status: 'Pending',
//     inwardNumber: '',
//     inwardDate: '',
//     receivingDate: '',
//     description: ''
//   });
//   const [selectedFile, setSelectedFile] = useState(null);
//   const [filePreview, setFilePreview] = useState(null);

//   // Supported file types with their MIME types
//   const supportedFileTypes = {
//     // Documents
//     'application/pdf': { icon: '📄', category: 'document' },
//     'application/msword': { icon: '📝', category: 'document' },
//     'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { icon: '📝', category: 'document' },
    
//     // Spreadsheets
//     'application/vnd.ms-excel': { icon: '📊', category: 'spreadsheet' },
//     'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { icon: '📊', category: 'spreadsheet' },
//     'text/csv': { icon: '📈', category: 'spreadsheet' },
    
//     // Images
//     'image/jpeg': { icon: '🖼️', category: 'image' },
//     'image/jpg': { icon: '🖼️', category: 'image' },
//     'image/png': { icon: '🖼️', category: 'image' },
//     'image/gif': { icon: '🖼️', category: 'image' },
//     'image/bmp': { icon: '🖼️', category: 'image' },
//     'image/webp': { icon: '🖼️', category: 'image' },
    
//     // Text files
//     'text/plain': { icon: '📃', category: 'text' },
//     'text/rtf': { icon: '📃', category: 'text' },
    
//     // Presentations
//     'application/vnd.ms-powerpoint': { icon: '📊', category: 'presentation' },
//     'application/vnd.openxmlformats-officedocument.presentationml.presentation': { icon: '📊', category: 'presentation' },
    
//     // Archives
//     'application/zip': { icon: '🗂️', category: 'archive' },
//     'application/x-rar-compressed': { icon: '🗂️', category: 'archive' }
//   };


// useEffect(() => {
//   if (selectedId) {
//     const fetchData = async () => {
//       try {
//         const dbRefInstance = dbRef(database);
//         const snapshot = await get(child(dbRefInstance, `data/${selectedId}`));
//         if (snapshot.exists()) {
//           const data = snapshot.val();

//           // Prefill form fields with fetched data
//           setFormData({
//             department: data.department || '',
//             receivedFrom: data.receivedFrom || '',
//             subject: data.subject || '',
//             allocatedTo: data.allocatedTo || '',
//             status: data.status || 'Pending',
//             inwardNumber: data.inwardNumber || '',
//             inwardDate: data.inwardDate || '',
//             receivingDate: data.receivingDate || '',
//             description: data.description || '',
//           });

//           // Set initialFileInfo if you want to show original file info or preview
//           setInitialFileInfo(data);

//           // You might want to show existing file preview if it's an image
//           if (data.fileType?.startsWith('image/')) {
//             setFilePreview(data.fileURL);
//           }

//           setIsEditing(true);
//         } else {
//           console.warn(`No data found for id: ${selectedId}`);
//         }
//       } catch (error) {
//         console.error('Error fetching record for edit:', error);
//       }
//     };

//     fetchData();
//   }
// }, [selectedId]);



//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData(prev => ({
//       ...prev,
//       [name]: value
//     }));
//   };

//   const getFileIcon = (fileType) => {
//     return supportedFileTypes[fileType]?.icon || '📎';
//   };

//   const getFileCategory = (fileType) => {
//     return supportedFileTypes[fileType]?.category || 'other';
//   };

//   const formatFileSize = (bytes) => {
//     if (bytes === 0) return '0 Bytes';
//     const k = 1024;
//     const sizes = ['Bytes', 'KB', 'MB', 'GB'];
//     const i = Math.floor(Math.log(bytes) / Math.log(k));
//     return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
//   };


  
//   const createImagePreview = (file) => {
//     if (file.type.startsWith('image/')) {
//       const reader = new FileReader();
//       reader.onload = (e) => {
//         setFilePreview(e.target.result);
//       };
//       reader.readAsDataURL(file);
//     } else {
//       setFilePreview(null);
//     }
//   };

//   const handleFileSelect = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       const maxSize = 50 * 1024 * 1024; // 50MB
//       if (file.size > maxSize) {
//         alert('File size must be less than 50MB');
//         e.target.value = ''; // Clear the input
//         return;
//       }
      
//       console.log('File selected:', {
//         name: file.name,
//         type: file.type,
//         size: formatFileSize(file.size)
//       });
      
//       setSelectedFile(file);
//       createImagePreview(file);
//     }
//   };

//   const uploadFile = async (file) => {
//     if (!currentUser) {
//       throw new Error('User must be authenticated to upload files');
//     }

//     console.log('🚀 Starting upload for:', file.name);
    
//     try {
//       const fileExtension = file.name.split('.').pop().toLowerCase();
//       const fileName = `${Date.now()}_${uuidv4()}.${fileExtension}`;
//       const category = getFileCategory(file.type);
//       const filePath = `files/${currentUser.uid}/${category}/${fileName}`;
      
//       console.log('📁 Upload path:', filePath);

//       const storageRef = ref(storage, filePath);
      
//       const metadata = {
//         contentType: file.type,
//         customMetadata: {
//           uploadedBy: currentUser.uid,
//           uploaderEmail: currentUser.email || '',
//           originalName: file.name,
//           category: category
//         }
//       };

//       const uploadTask = uploadBytesResumable(storageRef, file, metadata);
      
//       return new Promise((resolve, reject) => {
//         uploadTask.on(
//           'state_changed',
//           (snapshot) => {
//             const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
//             setUploadProgress(Math.round(progress));
//             console.log('📊 Progress:', Math.round(progress) + '%');
//           },
//           (error) => {
//             console.error('❌ Upload error:', error);
//             reject(new Error(`Upload failed: ${error.message}`));
//           },
//           async () => {
//             try {
//               console.log('✅ Upload complete, getting download URL...');
//               const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
//               console.log('✅ Download URL obtained');
              
//               resolve({
//                 fileName: file.name,
//                 fileURL: downloadURL,
//                 fileSize: file.size,
//                 fileType: file.type,
//                 fileCategory: category,
//                 storagePath: filePath
//               });
//             } catch (error) {
//               console.error('❌ Error getting download URL:', error);
//               reject(new Error(`Failed to get download URL: ${error.message}`));
//             }
//           }
//         );
//       });
//     } catch (error) {
//       console.error('❌ Upload setup failed:', error);
//       throw new Error(`Upload setup failed: ${error.message}`);
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
    
//     console.log('📤 Form submitted');
    
//     if (!currentUser) {
//       alert('Please log in to upload files');
//       return;
//     }

//     if (!selectedFile) {
//       alert('Please select a file to upload');
//       return;
//     }

//     if (!formData.department || !formData.subject) {
//       alert('Please fill in Department and Subject fields');
//       return;
//     }

//     setUploading(true);
//     setUploadProgress(0);

//     try {
//       console.log('🚀 Starting upload process...');
      
//       const uploadResult = await uploadFile(selectedFile);
//       console.log('✅ File uploaded successfully');
      
//       const recordData = {
//         ...formData,
//         ...uploadResult,
//         uploadedBy: currentUser.uid,
//         uploaderEmail: currentUser.email || '',
//         createdAt: Date.now(),
//         updatedAt: Date.now(),
//         fileIcon: getFileIcon(selectedFile.type)
//       };

//       const dataRef = dbRef(database, 'data');
//       const newRecordRef = await push(dataRef, recordData);
//       console.log('✅ Record saved with key:', newRecordRef.key);
      
//       alert(`✅ File uploaded successfully!\n\nFile: ${selectedFile.name}\nSize: ${formatFileSize(selectedFile.size)}\nCategory: ${getFileCategory(selectedFile.type)}\nRecord ID: ${newRecordRef.key}`);
      
//       console.log('🔄 Resetting form...');
//       setFormData({
//         department: '',
//         receivedFrom: '',
//         subject: '',
//         allocatedTo: '',
//         status: 'Pending',
//         inwardNumber: '',
//         inwardDate: '',
//         receivingDate: '',
//         description: ''
//       });
      
//       setSelectedFile(null);
//       setFilePreview(null);
      
//       const fileInput = document.getElementById('file-input');
//       if (fileInput) {
//         fileInput.value = '';
//       }
      
//       console.log('✅ Upload process completed successfully');
      
//     } catch (error) {
//       console.error('❌ Upload process failed:', error);
//       alert(`❌ Failed to upload file: ${error.message}`);
//     } finally {
//       console.log('🔄 Resetting upload state...');
//       setUploading(false);
//       setUploadProgress(0);
//     }
//   };

//   const handleClearFile = () => {
//     setSelectedFile(null);
//     setFilePreview(null);
//     const fileInput = document.getElementById('file-input');
//     if (fileInput) {
//       fileInput.value = '';
//     }
//   };

//   return (
//     <div className="upload-container">
//       <div className="upload-header">
//         <h2>📤 Upload Files</h2>
//         <p>Support for PDF, Word, Excel, Images, Text files and more</p>
//       </div>

//       <form onSubmit={handleSubmit} className="upload-form">
//         {/* File Upload Section */}
//         <div className="file-upload-section">
//           <label htmlFor="file-input" className="file-upload-label">
//             📎 Select File *
//             <input
//               type="file"
//               id="file-input"
//               onChange={handleFileSelect}
//               accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.jpg,.jpeg,.png,.gif,.bmp,.webp,.txt,.rtf,.ppt,.pptx,.zip,.rar"
//               required
//               disabled={uploading}
//             />
//           </label>

//           {selectedFile && (
//             <div className="selected-file-info">
//               <div className="file-details">
//                 <span className="file-icon">{getFileIcon(selectedFile.type)}</span>
//                 <div className="file-meta">
//                   <strong>{selectedFile.name}</strong>
//                   <div className="file-stats">
//                     <span>Size: {formatFileSize(selectedFile.size)}</span>
//                     <span>Type: {getFileCategory(selectedFile.type)}</span>
//                   </div>
//                 </div>
//                 <button
//                   type="button"
//                   onClick={handleClearFile}
//                   className="clear-file-btn"
//                   disabled={uploading}
//                 >
//                   ✕
//                 </button>
//               </div>

//               {filePreview && (
//                 <div className="image-preview">
//                   <img src={filePreview} alt="Preview" />
//                 </div>
//               )}
//             </div>
//           )}
//         </div>

//         {/* Form Fields */}
//         <div className="form-grid">
//           <div className="form-group">
//             <label htmlFor="department">Department *</label>
//             <select
//               id="department"
//               name="department"
//               value={formData.department}
//               onChange={handleInputChange}
//               required
//               disabled={uploading}
//             >
//               <option value="">Select Department</option>
//               <option value="Public Representation">Public Representation</option>
//               <option value="Executive Engineer">Executive Engineer</option>
//               <option value="Contractor">Contractor</option>
//               <option value="Farmer">Farmer</option>
//               <option value="Other">Other</option>
             
//             </select>
//           </div>

//           <div className="form-group">
//             <label htmlFor="subject">Subject *</label>
//             <input
//               type="text"
//               id="subject"
//               name="subject"
//               value={formData.subject}
//               onChange={handleInputChange}
//               placeholder="Enter document subject"
//               required
//               disabled={uploading}
//             />
//           </div>

//           <div className="form-group">
//             <label htmlFor="receivedFrom">Received From</label>
//             <input
//               type="text"
//               id="receivedFrom"
//               name="receivedFrom"
//               value={formData.receivedFrom}
//               onChange={handleInputChange}
//               placeholder="Enter sender name"
//               disabled={uploading}
//             />
//           </div>

//           <div className="form-group">
//             <label htmlFor="allocatedTo">Allocated To</label>
//             <input
//               type="text"
//               id="allocatedTo"
//               name="allocatedTo"
//               value={formData.allocatedTo}
//               onChange={handleInputChange}
//               placeholder="Enter assignee name"
//               disabled={uploading}
//             />
//           </div>

//           <div className="form-group">
//             <label htmlFor="status">Status</label>
//             <select
//               id="status"
//               name="status"
//               value={formData.status}
//               onChange={handleInputChange}
//               disabled={uploading}
//             >
//               <option value="Pending">Pending</option>
//               <option value="In Progress">In Progress</option>
//               <option value="Under Review">Under Review</option>
//               <option value="Completed">Completed</option>
//               <option value="On Hold">On Hold</option>
//               <option value="Rejected">Rejected</option>
//               <option value="Archived">Archived</option>
//             </select>
//           </div>

//           <div className="form-group">
//             <label htmlFor="inwardNumber">Inward Number</label>
//             <input
//               type="text"
//               id="inwardNumber"
//               name="inwardNumber"
//               value={formData.inwardNumber}
//               onChange={handleInputChange}
//               placeholder="Enter inward number"
//               disabled={uploading}
//             />
//           </div>

//           <div className="form-group">
//             <label htmlFor="inwardDate">Inward Date</label>
//             <input
//               type="date"
//               id="inwardDate"
//               name="inwardDate"
//               value={formData.inwardDate}
//               onChange={handleInputChange}
//               disabled={uploading}
//             />
//           </div>

//           <div className="form-group">
//             <label htmlFor="receivingDate">Receiving Date</label>
//             <input
//               type="date"
//               id="receivingDate"
//               name="receivingDate"
//               value={formData.receivingDate}
//               onChange={handleInputChange}
//               disabled={uploading}
//             />
//           </div>
//         </div>

//         <div className="form-group full-width">
//           <label htmlFor="description">Description</label>
//           <textarea
//             id="description"
//             name="description"
//             value={formData.description}
//             onChange={handleInputChange}
//             placeholder="Enter additional description or notes"
//             rows={3}
//             disabled={uploading}
//           />
//         </div>

//         {/* Upload Progress */}
//         {uploading && (
//           <div className="upload-progress">
//             <div className="progress-info">
//               <span>📤 Uploading {selectedFile?.name}...</span>
//               <span className="progress-percentage">{uploadProgress}%</span>
//             </div>
//             <div className="progress-bar">
//               <div
//                 className="progress-fill"
//                 style={{ width: `${uploadProgress}%` }}
//               ></div>
//             </div>
//             <div className="upload-status">
//               {uploadProgress === 100 ? 'Processing...' : 'Uploading...'}
//             </div>
//           </div>
//         )}

//         {/* Submit Button */}
//         <div className="form-actions">
//           <button
//             type="submit"
//             className={`upload-btn ${uploading ? 'uploading' : ''}`}
//             disabled={uploading || !selectedFile}
//           >
//             {uploading ? (
//               <>
//                 <span className="spinner"></span>
//                 Uploading...
//               </>
//             ) : (
//               '📤 Upload File'
//             )}
//           </button>
//         </div>
//       </form>

//     <style jsx>{`
//   .upload-container {
//     width: 95%;
//     max-width: 950px;
//     margin: 2rem auto;
//     padding: 2.5rem;
//     background: linear-gradient(to top left, #ffffff, #f8fafc);
//     border-radius: 16px;
//     border: 1px solid #e2e8f0;
//     box-shadow: 0 12px 28px rgba(0, 0, 0, 0.08);
//     font-family: 'Inter', sans-serif;
//   }

//   /* Header */
//   .upload-header {
//     margin-bottom: 1.5rem;
//     text-align: center;
//   }
//   .upload-header h2 {
//     font-size: 2.2rem;
//     font-weight: 800;
//     background: linear-gradient(90deg, #4f46e5, #9333ea);
//     -webkit-background-clip: text;
//     -webkit-text-fill-color: transparent;
//     margin-bottom: 0.4rem;
//   }
//   .upload-header p {
//     color: #64748b;
//     font-size: 1rem;
//     font-weight: 500;
//   }

//   /* File Upload */
//   .file-upload-section {
//     border: 2.5px dashed #cbd5e1;
//     border-radius: 14px;
//     padding: 1.8rem;
//     background: #f9fafb;
//     text-align: center;
//     transition: background-color 0.3s ease, border-color 0.3s ease;
//   }
//   .file-upload-section:hover {
//     background-color: #eef2ff;
//     border-color: #6366f1;
//   }
//   .file-upload-label {
//     font-size: 1.05rem;
//     font-weight: 600;
//     color: #334155;
//     cursor: pointer;
//   }
//   .file-upload-label input {
//     display: none;
//   }

//   /* Selected file info */
//   .selected-file-info {
//     margin-top: 1rem;
//     padding: 1rem 1.2rem;
//     background-color: #f8fafc;
//     border-radius: 12px;
//     display: flex;
//     align-items: center;
//     justify-content: space-between;
//     gap: 1rem;
//     border: 1px solid #e5e7eb;
//   }
//   .file-details {
//     display: flex;
//     align-items: center;
//     gap: 1rem;
//   }
//   .file-icon {
//     font-size: 2rem;
//   }
//   .file-meta strong {
//     display: block;
//     font-size: 1rem;
//     font-weight: 700;
//     color: #1e293b;
//   }
//   .file-stats {
//     font-size: 0.9rem;
//     color: #475569;
//   }
//   .clear-file-btn {
//     background: none;
//     border: none;
//     color: #ef4444;
//     font-weight: bold;
//     font-size: 1.4rem;
//     cursor: pointer;
//   }

//   /* Image Preview */
//   .image-preview {
//     margin-top: 1rem;
//     max-width: 300px;
//     border-radius: 10px;
//     overflow: hidden;
//     border: 1px solid #e2e8f0;
//     box-shadow: 0 3px 10px rgba(0,0,0,0.07);
//   }
//   .image-preview img {
//     width: 100%;
//     height: auto;
//     display: block;
//   }

//   /* Form Layout */
//   .form-grid {
//     display: grid;
//     grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
//     gap: 1.5rem 2rem;
//     margin-top: 2rem;
//   }
//   .form-group {
//     display: flex;
//     flex-direction: column;
//     gap: 0.4rem;
//   }
//   .form-group label {
//     font-weight: 600;
//     color: #334155;
//   }
//   .form-group input, 
//   .form-group select, 
//   .form-group textarea {
//     padding: 0.75rem 1rem;
//     border-radius: 10px;
//     border: 1.4px solid #cbd5e1;
//     font-size: 1rem;
//     background: #ffffff;
//     transition: all 0.25s ease;
//   }
//   .form-group input:focus,
//   .form-group select:focus,
//   .form-group textarea:focus {
//     border-color: #6366f1;
//     box-shadow: 0 0 6px rgba(99,102,241,0.4);
//   }

//   /* Progress */
//   .upload-progress {
//     margin-top: 1rem;
//     padding: 1.2rem;
//     background: #f1f5f9;
//     border-radius: 10px;
//   }
//   .progress-bar {
//     width: 100%;
//     height: 10px;
//     background: #e0e7ff;
//     border-radius: 999px;
//     overflow: hidden;
//   }
//   .progress-fill {
//     height: 100%;
//     background: linear-gradient(90deg, #6366f1, #9333ea);
//     transition: width 0.35s ease;
//   }

//   /* Submit Button */
//   .form-actions {
//     margin-top: 2rem;
//     display: flex;
//     justify-content: flex-end;
//   }
//   .upload-btn {
//     padding: 0.9rem 2.5rem;
//     background: linear-gradient(90deg, #4f46e5, #9333ea);
//     border: none;
//     border-radius: 12px;
//     color: white;
//     font-weight: 700;
//     font-size: 1.1rem;
//     cursor: pointer;
//     transition: all 0.3s ease;
//     box-shadow: 0 8px 20px rgba(79,70,229,0.4);
//   }
//   .upload-btn:hover:not(:disabled) {
//     background: linear-gradient(90deg, #4338ca, #7e22ce);
//     transform: translateY(-2px);
//     box-shadow: 0 10px 30px rgba(147,51,234,0.5);
//   }
//   .upload-btn:disabled {
//     opacity: 0.6;
//     cursor: not-allowed;
//   }
// `}</style>

//     </div>
//   );
// };

// export default FileUpload;




import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db, storage, database } from '../firebase';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { ref as dbRef, push } from 'firebase/database';
import { v4 as uuidv4 } from 'uuid';
import { useParams } from 'react-router-dom'; 
import { get, child } from 'firebase/database';

const FileUpload = ({ selectedId }) => {
  console.log("selectedId", selectedId);

  const { currentUser } = useAuth();
  const { id } = useParams();
  const [isEditing, setIsEditing] = useState(false);
  const [initialFileInfo, setInitialFileInfo] = useState(null);

  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [formData, setFormData] = useState({
    department: '',
    publicRepType: '', // New state for MLA/MP selection
    receivedFrom: '',
    subject: '',
    allocatedTo: '',
    status: 'Pending',
    inwardNumber: '',
    inwardDate: '',
    receivingDate: '',
    description: ''
  });
  const [selectedFile, setSelectedFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);

  // Supported file types mapping as before
  const supportedFileTypes = {
    'application/pdf': { icon: '📄', category: 'document' },
    'application/msword': { icon: '📝', category: 'document' },
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { icon: '📝', category: 'document' },
    'application/vnd.ms-excel': { icon: '📊', category: 'spreadsheet' },
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { icon: '📊', category: 'spreadsheet' },
    'text/csv': { icon: '📈', category: 'spreadsheet' },
    'image/jpeg': { icon: '🖼️', category: 'image' },
    'image/jpg': { icon: '🖼️', category: 'image' },
    'image/png': { icon: '🖼️', category: 'image' },
    'image/gif': { icon: '🖼️', category: 'image' },
    'image/bmp': { icon: '🖼️', category: 'image' },
    'image/webp': { icon: '🖼️', category: 'image' },
    'text/plain': { icon: '📃', category: 'text' },
    'text/rtf': { icon: '📃', category: 'text' },
    'application/vnd.ms-powerpoint': { icon: '📊', category: 'presentation' },
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': { icon: '📊', category: 'presentation' },
    'application/zip': { icon: '🗂️', category: 'archive' },
    'application/x-rar-compressed': { icon: '🗂️', category: 'archive' }
  };

  useEffect(() => {
    if (selectedId) {
      const fetchData = async () => {
        try {
          const dbRefInstance = dbRef(database);
          const snapshot = await get(child(dbRefInstance, `data/${selectedId}`));
          if (snapshot.exists()) {
            const data = snapshot.val();

            setFormData({
              department: data.department || '',
              publicRepType: data.publicRepType || '',
              receivedFrom: data.receivedFrom || '',
              subject: data.subject || '',
              allocatedTo: data.allocatedTo || '',
              status: data.status || 'Pending',
              inwardNumber: data.inwardNumber || '',
              inwardDate: data.inwardDate || '',
              receivingDate: data.receivingDate || '',
              description: data.description || ''
            });

            setInitialFileInfo(data);

            if (data.fileType?.startsWith('image/')) {
              setFilePreview(data.fileURL);
            }

            setIsEditing(true);
          } else {
            console.warn(`No data found for id: ${selectedId}`);
          }
        } catch (error) {
          console.error('Error fetching record for edit:', error);
        }
      };

      fetchData();
    }
  }, [selectedId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const getFileIcon = (fileType) => {
    return supportedFileTypes[fileType]?.icon || '📎';
  };

  const getFileCategory = (fileType) => {
    return supportedFileTypes[fileType]?.category || 'other';
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const createImagePreview = (file) => {
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFilePreview(e.target.result);
      };
      reader.readAsDataURL(file);
    } else {
      setFilePreview(null);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const maxSize = 50 * 1024 * 1024; // 50MB
      if (file.size > maxSize) {
        alert('File size must be less than 50MB');
        e.target.value = '';
        return;
      }

      console.log('File selected:', {
        name: file.name,
        type: file.type,
        size: formatFileSize(file.size)
      });

      setSelectedFile(file);
      createImagePreview(file);
    }
  };

  const uploadFile = async (file) => {
    if (!currentUser) {
      throw new Error('User must be authenticated to upload files');
    }
    console.log('🚀 Starting upload for:', file.name);

    try {
      const fileExtension = file.name.split('.').pop().toLowerCase();
      const fileName = `${Date.now()}_${uuidv4()}.${fileExtension}`;
      const category = getFileCategory(file.type);
      const filePath = `files/${currentUser.uid}/${category}/${fileName}`;

      console.log('📁 Upload path:', filePath);

      const storageRef = ref(storage, filePath);

      const metadata = {
        contentType: file.type,
        customMetadata: {
          uploadedBy: currentUser.uid,
          uploaderEmail: currentUser.email || '',
          originalName: file.name,
          category: category
        }
      };

      const uploadTask = uploadBytesResumable(storageRef, file, metadata);

      return new Promise((resolve, reject) => {
        uploadTask.on(
          'state_changed',
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            setUploadProgress(Math.round(progress));
            console.log('📊 Progress:', Math.round(progress) + '%');
          },
          (error) => {
            console.error('❌ Upload error:', error);
            reject(new Error(`Upload failed: ${error.message}`));
          },
          async () => {
            try {
              console.log('✅ Upload complete, getting download URL...');
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
              console.log('✅ Download URL obtained');

              resolve({
                fileName: file.name,
                fileURL: downloadURL,
                fileSize: file.size,
                fileType: file.type,
                fileCategory: category,
                storagePath: filePath
              });
            } catch (error) {
              console.error('❌ Error getting download URL:', error);
              reject(new Error(`Failed to get download URL: ${error.message}`));
            }
          }
        );
      });
    } catch (error) {
      console.error('❌ Upload setup failed:', error);
      throw new Error(`Upload setup failed: ${error.message}`);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log('📤 Form submitted');

    if (!currentUser) {
      alert('Please log in to upload files');
      return;
    }

    if (!selectedFile) {
      alert('Please select a file to upload');
      return;
    }

    if (!formData.department || !formData.subject) {
      alert('Please fill in Department and Subject fields');
      return;
    }

    // If department is Public Representation, ensure publicRepType selected
    if (formData.department === 'Public Representation' && !formData.publicRepType) {
      alert('Please select MLA or MP');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      console.log('🚀 Starting upload process...');
      const uploadResult = await uploadFile(selectedFile);
      console.log('✅ File uploaded successfully');

      const recordData = {
        ...formData,
        ...uploadResult,
        uploadedBy: currentUser.uid,
        uploaderEmail: currentUser.email || '',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        fileIcon: getFileIcon(selectedFile.type)
      };

      const dataRef = dbRef(database, 'data');
      const newRecordRef = await push(dataRef, recordData);
      console.log('✅ Record saved with key:', newRecordRef.key);

      alert(`✅ File uploaded successfully!\n\nFile: ${selectedFile.name}\nSize: ${formatFileSize(selectedFile.size)}\nCategory: ${getFileCategory(selectedFile.type)}\nRecord ID: ${newRecordRef.key}`);

      console.log('🔄 Resetting form...');
      setFormData({
        department: '',
        publicRepType: '',
        receivedFrom: '',
        subject: '',
        allocatedTo: '',
        status: 'Pending',
        inwardNumber: '',
        inwardDate: '',
        receivingDate: '',
        description: ''
      });

      setSelectedFile(null);
      setFilePreview(null);

      const fileInput = document.getElementById('file-input');
      if (fileInput) {
        fileInput.value = '';
      }

      console.log('✅ Upload process completed successfully');
    } catch (error) {
      console.error('❌ Upload process failed:', error);
      alert(`❌ Failed to upload file: ${error.message}`);
    } finally {
      console.log('🔄 Resetting upload state...');
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleClearFile = () => {
    setSelectedFile(null);
    setFilePreview(null);
    const fileInput = document.getElementById('file-input');
    if (fileInput) {
      fileInput.value = '';
    }
  };

  return (
    <div className="upload-container">
      <div className="upload-header">
        <h2>📤 Upload Files</h2>
        <p>Support for PDF, Word, Excel, Images, Text files and more</p>
      </div>

      <form onSubmit={handleSubmit} className="upload-form">
        {/* File Upload Section */}
        <div className="file-upload-section">
          <label htmlFor="file-input" className="file-upload-label">
            📎 Select File *
            <input
              type="file"
              id="file-input"
              onChange={handleFileSelect}
              accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.jpg,.jpeg,.png,.gif,.bmp,.webp,.txt,.rtf,.ppt,.pptx,.zip,.rar"
              required
              disabled={uploading}
            />
          </label>

          {selectedFile && (
            <div className="selected-file-info">
              <div className="file-details">
                <span className="file-icon">{getFileIcon(selectedFile.type)}</span>
                <div className="file-meta">
                  <strong>{selectedFile.name}</strong>
                  <div className="file-stats">
                    <span>Size: {formatFileSize(selectedFile.size)}</span>
                    <span>Type: {getFileCategory(selectedFile.type)}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleClearFile}
                  className="clear-file-btn"
                  disabled={uploading}
                >
                  ✕
                </button>
              </div>

              {filePreview && (
                <div className="image-preview">
                  <img src={filePreview} alt="Preview" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Form Fields */}
        <div className="form-grid">
          <div className="form-group">
            <label htmlFor="department">Department *</label>
            <select
              id="department"
              name="department"
              value={formData.department}
              onChange={handleInputChange}
              required
              disabled={uploading}
            >
              <option value="">Select Department</option>
              <option value="Public Representation">Public Representation</option>
              <option value="Executive Engineer">Executive Engineer</option>
              <option value="Contractor">Contractor</option>
              <option value="Farmer">Farmer</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {/* Conditional spinner for MLA or MP when Public Representation selected */}
          {formData.department === 'Public Representation' && (
            <div className="form-group">
              <label htmlFor="publicRepType">Select Type *</label>
              <select
                id="publicRepType"
                name="publicRepType"
                value={formData.publicRepType}
                onChange={handleInputChange}
                required={formData.department === 'Public Representation'}
                disabled={uploading}
              >
                <option value="">Select</option>
                <option value="MLA">MLA</option>
                <option value="MP">MP</option>
              </select>
            </div>
          )}

          <div className="form-group">
            <label htmlFor="subject">Subject *</label>
            <input
              type="text"
              id="subject"
              name="subject"
              value={formData.subject}
              onChange={handleInputChange}
              placeholder="Enter document subject"
              required
              disabled={uploading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="receivedFrom">Received From</label>
            <input
              type="text"
              id="receivedFrom"
              name="receivedFrom"
              value={formData.receivedFrom}
              onChange={handleInputChange}
              placeholder="Enter sender name"
              disabled={uploading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="allocatedTo">Allocated To</label>
            <input
              type="text"
              id="allocatedTo"
              name="allocatedTo"
              value={formData.allocatedTo}
              onChange={handleInputChange}
              placeholder="Enter assignee name"
              disabled={uploading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="status">Status</label>
            <select
              id="status"
              name="status"
              value={formData.status}
              onChange={handleInputChange}
              disabled={uploading}
            >
              <option value="Pending">Pending</option>
              <option value="In Progress">In Progress</option>
              <option value="Under Review">Under Review</option>
              <option value="Completed">Completed</option>
              <option value="On Hold">On Hold</option>
              <option value="Rejected">Rejected</option>
              <option value="Archived">Archived</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="inwardNumber">Inward Number</label>
            <input
              type="text"
              id="inwardNumber"
              name="inwardNumber"
              value={formData.inwardNumber}
              onChange={handleInputChange}
              placeholder="Enter inward number"
              disabled={uploading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="inwardDate">Inward Date</label>
            <input
              type="date"
              id="inwardDate"
              name="inwardDate"
              value={formData.inwardDate}
              onChange={handleInputChange}
              disabled={uploading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="receivingDate">Receiving Date</label>
            <input
              type="date"
              id="receivingDate"
              name="receivingDate"
              value={formData.receivingDate}
              onChange={handleInputChange}
              disabled={uploading}
            />
          </div>
        </div>

        <div className="form-group full-width">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            placeholder="Enter additional description or notes"
            rows={3}
            disabled={uploading}
          />
        </div>

        {/* Upload Progress */}
        {uploading && (
          <div className="upload-progress">
            <div className="progress-info">
              <span>📤 Uploading {selectedFile?.name}...</span>
              <span className="progress-percentage">{uploadProgress}%</span>
            </div>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <div className="upload-status">
              {uploadProgress === 100 ? 'Processing...' : 'Uploading...'}
            </div>
          </div>
        )}

        <div className="form-actions">
          <button
            type="submit"
            className={`upload-btn ${uploading ? 'uploading' : ''}`}
            disabled={uploading || !selectedFile}
          >
            {uploading ? (
              <>
                <span className="spinner"></span>
                Uploading...
              </>
            ) : (
              '📤 Upload File'
            )}
          </button>
        </div>
      </form>

      <style jsx>{`
        .upload-container {
          width: 95%;
          max-width: 950px;
          margin: 2rem auto;
          padding: 2.5rem;
          background: linear-gradient(to top left, #ffffff, #f8fafc);
          border-radius: 16px;
          border: 1px solid #e2e8f0;
          box-shadow: 0 12px 28px rgba(0, 0, 0, 0.08);
          font-family: 'Inter', sans-serif;
        }
        .upload-header {
          margin-bottom: 1.5rem;
          text-align: center;
        }
        .upload-header h2 {
          font-size: 2.2rem;
          font-weight: 800;
          background: linear-gradient(90deg, #4f46e5, #9333ea);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 0.4rem;
        }
        .upload-header p {
          color: #64748b;
          font-size: 1rem;
          font-weight: 500;
        }
        .file-upload-section {
          border: 2.5px dashed #cbd5e1;
          border-radius: 14px;
          padding: 1.8rem;
          background: #f9fafb;
          text-align: center;
          transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .file-upload-section:hover {
          background-color: #eef2ff;
          border-color: #6366f1;
        }
        .file-upload-label {
          font-size: 1.05rem;
          font-weight: 600;
          color: #334155;
          cursor: pointer;
        }
        .file-upload-label input {
          display: none;
        }
        .selected-file-info {
          margin-top: 1rem;
          padding: 1rem 1.2rem;
          background-color: #f8fafc;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 1rem;
          border: 1px solid #e5e7eb;
        }
        .file-details {
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        .file-icon {
          font-size: 2rem;
        }
        .file-meta strong {
          display: block;
          font-size: 1rem;
          font-weight: 700;
          color: #1e293b;
        }
        .file-stats {
          font-size: 0.9rem;
          color: #475569;
        }
        .clear-file-btn {
          background: none;
          border: none;
          color: #ef4444;
          font-weight: bold;
          font-size: 1.4rem;
          cursor: pointer;
        }
        .image-preview {
          margin-top: 1rem;
          max-width: 300px;
          border-radius: 10px;
          overflow: hidden;
          border: 1px solid #e2e8f0;
          box-shadow: 0 3px 10px rgba(0, 0, 0, 0.07);
        }
        .image-preview img {
          width: 100%;
          height: auto;
          display: block;
        }
        .form-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 1.5rem 2rem;
          margin-top: 2rem;
        }
        .form-group {
          display: flex;
          flex-direction: column;
          gap: 0.4rem;
        }
        .form-group label {
          font-weight: 600;
          color: #334155;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
          padding: 0.75rem 1rem;
          border-radius: 10px;
          border: 1.4px solid #cbd5e1;
          font-size: 1rem;
          background: #ffffff;
          transition: all 0.25s ease;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
          border-color: #6366f1;
          box-shadow: 0 0 6px rgba(99, 102, 241, 0.4);
        }
        .upload-progress {
          margin-top: 1rem;
          padding: 1.2rem;
          background: #f1f5f9;
          border-radius: 10px;
        }
        .progress-bar {
          width: 100%;
          height: 10px;
          background: #e0e7ff;
          border-radius: 999px;
          overflow: hidden;
        }
        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #6366f1, #9333ea);
          transition: width 0.35s ease;
        }
        .form-actions {
          margin-top: 2rem;
          display: flex;
          justify-content: flex-end;
        }
        .upload-btn {
          padding: 0.9rem 2.5rem;
          background: linear-gradient(90deg, #4f46e5, #9333ea);
          border: none;
          border-radius: 12px;
          color: white;
          font-weight: 700;
          font-size: 1.1rem;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: 0 8px 20px rgba(79, 70, 229, 0.4);
        }
        .upload-btn:hover:not(:disabled) {
          background: linear-gradient(90deg, #4338ca, #7e22ce);
          transform: translateY(-2px);
          box-shadow: 0 10px 30px rgba(147, 51, 234, 0.5);
        }
        .upload-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
      `}</style>
    </div>
  );
};

export default FileUpload;
