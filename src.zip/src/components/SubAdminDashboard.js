// src/components/SubAdminDashboard.js
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { db } from '../firebase';
import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import FileUpload from './FileUpload'; // Import your existing FileUpload component
import RecordsView from './RecordsView'; // Import your existing RecordsView component
import '../styles/SubAdminDashboard.css'; // Import the CSS styles
import { database } from '../firebase';
import { ref, onValue } from 'firebase/database';

const SubAdminDashboard = () => {
  const { currentUser, userRole, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [stats, setStats] = useState({
    totalFiles: 0,
    pendingFiles: 0,
    completedFiles: 0,
    inProgressFiles: 0
  });
  const [recentFiles, setRecentFiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userRole === 'admin') {
      navigate('/dashboard');
      return;
    }
    fetchUserStats();
  }, [currentUser, userRole]);

  const fetchUserStats = () => {
    if (!currentUser) return;

    setLoading(true);

    const dataRef = ref(database, 'data'); // Uses RTDB
    onValue(dataRef, snapshot => {
      const data = snapshot.val();
      let files = [];
      if (data) {
        files = Object.entries(data).map(([id, value]) => ({
          id,
          ...value
        }));
      }

      // Filter to current user's files
      const userFiles = files.filter(f => f.uploadedBy === currentUser.uid);

      const totalFiles = userFiles.length;
      const pendingFiles = userFiles.filter(f => f.status === 'Pending').length;
      const completedFiles = userFiles.filter(f => f.status === 'Completed').length;
      const inProgressFiles = userFiles.filter(f => f.status === 'In Progress').length;

      setStats({
        totalFiles,
        pendingFiles,
        completedFiles,
        inProgressFiles
      });

      setRecentFiles(
        userFiles
          .sort((a, b) => Number(b.createdAt) - Number(a.createdAt))
          .slice(0, 5)
      );

      setLoading(false);
    }, error => {
      console.error('Error fetching stats:', error);
      setLoading(false);
    });
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Removed 'profile' and 'settings' from menuItems
  const menuItems = [
    { id: 'overview', label: 'Overview', icon: '📊' },
    { id: 'upload', label: 'Upload Files', icon: '📤' },
    { id: 'myfiles', label: 'My Files', icon: '📁' }
  ];

  // Removed 'profile' and 'settings' cases and components from renderContent
  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewContent stats={stats} recentFiles={recentFiles} loading={loading} setActiveTab={setActiveTab} />;
      case 'upload':
        return (
          <div className="dashboard-content-wrapper">
            <FileUpload />
          </div>
        );
      case 'myfiles':
        return (
          <div className="dashboard-content-wrapper">
            <RecordsView />
          </div>
        );
      default:
        return <OverviewContent stats={stats} recentFiles={recentFiles} loading={loading} setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="subadmin-dashboard">
      {/* Sidebar */}
      <div className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <div className="logo">
            <span className="logo-icon">🏢</span>
            {sidebarOpen && <span className="logo-text">SubAdmin Panel</span>}
          </div>
          <button
            className="sidebar-toggle"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? '◀' : '▶'}
          </button>
        </div>

        {/* Removed user-info section */}

        <nav className="sidebar-nav">
          {menuItems.map(item => (
            <button
              key={item.id}
              className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
              onClick={() => setActiveTab(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              {sidebarOpen && <span className="nav-label">{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* Keep only logout button in sidebar footer */}
        <div className="sidebar-footer">
          <button className="logout-btn" onClick={handleLogout}>
            <span className="nav-icon">🚪</span>
            {sidebarOpen && <span className="nav-label">Logout</span>}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className={`main-content ${sidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
        <div className="content-header">
          <h1>Welcome back, {currentUser?.email?.split('@')[0]}! 👋</h1>
          <div className="header-actions">
            <button className="notification-btn">
              🔔 <span className="notification-count">{stats.pendingFiles}</span>
            </button>
          </div>
        </div>

        <div className="content-body">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

// Overview Content Component (unchanged)
const OverviewContent = ({ stats, recentFiles, loading, setActiveTab }) => {
  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="overview-content">
      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card total">
          <div className="stat-icon">📄</div>
          <div className="stat-info">
            <div className="stat-number">{stats.totalFiles}</div>
            <div className="stat-label">Total Files</div>
          </div>
        </div>

        <div className="stat-card pending">
          <div className="stat-icon">⏳</div>
          <div className="stat-info">
            <div className="stat-number">{stats.pendingFiles}</div>
            <div className="stat-label">Pending</div>
          </div>
        </div>

        <div className="stat-card progress">
          <div className="stat-icon">🔄</div>
          <div className="stat-info">
            <div className="stat-number">{stats.inProgressFiles}</div>
            <div className="stat-label">In Progress</div>
          </div>
        </div>

        <div className="stat-card completed">
          <div className="stat-icon">✅</div>
          <div className="stat-info">
            <div className="stat-number">{stats.completedFiles}</div>
            <div className="stat-label">Completed</div>
          </div>
        </div>
      </div>

      {/* Recent Files */}
      <div className="recent-files-section">
        <h3>Recent Files</h3>
        {recentFiles.length === 0 ? (
          <div className="empty-state">
            <p>📄 No files uploaded yet</p>
            <p>Start by uploading your first file!</p>
          </div>
        ) : (
          <div className="recent-files-list">
            {recentFiles.map(file => (
              <div key={file.id} className="recent-file-item">
                <div className="file-icon">📄</div>
                <div className="file-details">
                  <div className="file-name">{file.fileName}</div>
                  <div className="file-subject">{file.subject}</div>
                  <div className="file-date">
                    {new Date(file.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <div className={`file-status ${file.status?.toLowerCase().replace(' ', '-')}`}>
                  {file.status || 'Pending'}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="quick-actions">
        <h3>Quick Actions</h3>
        <div className="action-buttons">
          <button
            className="action-btn upload"
            onClick={() => setActiveTab('upload')}
          >
            <span>📤</span>
            Upload New File
          </button>
          <button
            className="action-btn view"
            onClick={() => setActiveTab('myfiles')}
          >
            <span>👁️</span>
            View All Files
          </button>
          <button className="action-btn report">
            <span>📊</span>
            Generate Report
          </button>
        </div>
      </div>
    </div>
  );
};

export default SubAdminDashboard;
