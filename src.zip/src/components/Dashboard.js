import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { getDatabase, ref as dbRef, onValue } from 'firebase/database';
import { getStorage, ref as storageRef, uploadBytes, listAll, getDownloadURL, deleteObject } from 'firebase/storage';
import FileUpload from './FileUpload';
import FileRecordsList from './RecordsView';
import '../styles/Dashboard.css';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Download, Trash2, Eye, X } from 'lucide-react';

const Dashboard = () => {
  const { currentUser, userRole, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [stats, setStats] = useState({
    totalFiles: 0,
    pendingFiles: 0,
    completedFiles: 0,
  });

  useEffect(() => {
    if (userRole !== 'admin') {
      navigate('/subadmin-dashboard');
      return;
    }
    fetchDashboardStats();
  }, [currentUser, userRole, navigate]);

  const fetchDashboardStats = () => {
    const db = getDatabase();
    let filesData = [];
    let loadingCount = 1;

    const checkLoadingComplete = () => {
      loadingCount--;
      if (loadingCount === 0) {
        setLoading(false);
      }
    };

    const filesRef = dbRef(db, 'data');
    onValue(
      filesRef,
      (snapshot) => {
        const data = snapshot.val();
        if (data) {
          filesData = Object.entries(data).map(([id, file]) => ({
            id,
            ...file,
          }));
          setFiles(filesData);
        } else {
          setFiles([]);
          filesData = [];
        }
        updateStats(filesData);
        checkLoadingComplete();
      },
      (error) => {
        console.error('Error fetching files:', error);
        checkLoadingComplete();
      }
    );
  };

  const updateStats = (filesArray) => {
    const totalFiles = filesArray.length;
    const pendingFiles = filesArray.filter(
      (f) => f.status === 'Pending' || !f.status
    ).length;
    const completedFiles = filesArray.filter(
      (f) => f.status === 'Completed'
    ).length;

    setStats({
      totalFiles,
      pendingFiles,
      completedFiles,
    });
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const menuItems = [
    { id: 'overview', label: 'Overview', icon: '📊' },
    { id: 'files', label: 'File Uploads', icon: '📤' },
    { id: 'RecordsView', label: 'File Records', icon: '📋' },
    { id: 'portfolio', label: 'My Files', icon: '💼' },
  ];

const PortfolioContent = ({ currentUser }) => {
  const [portfolioFiles, setPortfolioFiles] = useState([]);
  const [loadingFiles, setLoadingFiles] = useState(true);
  const [error, setError] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);

  useEffect(() => {
    if (!currentUser?.uid) {
      setLoadingFiles(false);
      setError('User not authenticated');
      return;
    }

    const fetchFiles = async () => {
      try {
        const storage = getStorage();
        const folderRef = storageRef(storage, `personalFiles/${currentUser.uid}`);
        const fileList = await listAll(folderRef);
        const filesData = await Promise.all(
          fileList.items.map(async (itemRef) => {
            const url = await getDownloadURL(itemRef);
            return { name: itemRef.name, url, ref: itemRef };
          })
        );
        setPortfolioFiles(filesData);
        setError(null);
      } catch (error) {
        console.error('Error fetching portfolio files:', error);
        setError('Failed to load files');
      } finally {
        setLoadingFiles(false);
      }
    };

    fetchFiles();
  }, [currentUser]);

  const handleAddFilesClick = () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.pdf,.doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png';
    fileInput.onchange = async (event) => {
      const file = event.target.files[0];
      if (file && currentUser?.uid) {
        try {
          const storage = getStorage();
          const fileRef = storageRef(storage, `personalFiles/${currentUser.uid}/${file.name}`);
          await uploadBytes(fileRef, file);
          const url = await getDownloadURL(fileRef);
          setPortfolioFiles((prev) => [...prev, { name: file.name, url, ref: fileRef }]);
          alert('File uploaded successfully!');
        } catch (error) {
          alert('Error uploading file: ' + error.message);
          setError('Failed to upload file');
        }
      }
    };
    fileInput.click();
  };

  const handleDeleteFile = async (fileRef, fileName) => {
    if (window.confirm(`Are you sure you want to delete ${fileName}?`)) {
      try {
        await deleteObject(fileRef);
        setPortfolioFiles((prev) => prev.filter((file) => file.name !== fileName));
        alert('File deleted successfully!');
      } catch (error) {
        alert('Error deleting file: ' + error.message);
        setError('Failed to delete file');
      }
    }
  };

  const handleViewFile = (file) => {
    const ext = file.name.split('.').pop().toLowerCase();
    if (['jpg', 'jpeg', 'png'].includes(ext)) {
      setSelectedImage(file.url);
    } else {
      window.open(file.url, '_blank');
    }
  };

  const closeModal = () => {
    setSelectedImage(null);
  };

  const getFileIcon = (fileName) => {
    const ext = fileName.split('.').pop().toLowerCase();
    switch (ext) {
      case 'pdf':
        return '📄';
      case 'doc':
      case 'docx':
        return '📝';
      case 'xls':
      case 'xlsx':
        return '📊';
      case 'txt':
        return '📄';
      case 'jpg':
      case 'jpeg':
      case 'png':
        return '🖼️';
      default:
        return '📁';
    }
  };

  return (
    <motion.div
      className="portfolio-content"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      style={{
        maxWidth: '900px',
        margin: '40px auto',
        padding: '30px',
        background: 'linear-gradient(135deg, #ffffff, #f9fafb)',
        borderRadius: '16px',
        boxShadow: '0 8px 24px rgba(0, 0, 0, 0.1)',
      }}
    >
      <div className="content-header" style={{ textAlign: 'center', marginBottom: '30px' }}>
        <motion.h2
          initial={{ scale: 0.9 }}
          animate={{ scale: 1 }}
          style={{ fontSize: '28px', fontWeight: '700', color: '#1a202c' }}
        >
          💼 Your Portfolio
        </motion.h2>
        <p style={{ fontSize: '16px', color: '#4a5568', marginTop: '8px' }}>
          Organize and showcase your professional files with ease
        </p>
      </div>

      <div className="file-upload-section" style={{ textAlign: 'center', marginBottom: '40px' }}>
        <motion.button
          className="add-files-button"
          onClick={handleAddFilesClick}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          style={{
            padding: '12px 24px',
            background: 'linear-gradient(to right, #3b82f6, #2563eb)',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '16px',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            margin: '0 auto',
            boxShadow: '0 4px 12px rgba(59, 130, 246, 0.3)',
          }}
        >
          <Upload size={20} /> Upload New File
        </motion.button>
      </div>

      <div className="portfolio-files-list">
        <h3 style={{ fontSize: '20px', fontWeight: '600', color: '#1a202c', marginBottom: '20px' }}>
          Your Files
        </h3>
        {error && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            style={{ color: '#e53e3e', textAlign: 'center', marginBottom: '20px' }}
          >
            {error}
          </motion.p>
        )}
        {loadingFiles ? (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            style={{ textAlign: 'center', color: '#4a5568' }}
          >
            Loading files...
          </motion.p>
        ) : portfolioFiles.length === 0 ? (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            style={{ textAlign: 'center', color: '#4a5568', fontStyle: 'italic' }}
          >
            No files uploaded yet. Start by adding some files!
          </motion.p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0 }}>
            <AnimatePresence>
              {portfolioFiles.map((file, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  style={{
                    padding: '16px',
                    marginBottom: '12px',
                    backgroundColor: 'white',
                    borderRadius: '12px',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    transition: 'transform 0.2s',
                  }}
                  whileHover={{ transform: 'translateY(-2px)' }}
                >
                  <span style={{ fontSize: '16px', color: '#1a202c', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    {getFileIcon(file.name)} {file.name}
                  </span>
                  <div style={{ display: 'flex', gap: '12px' }}>
                    <motion.button
                      onClick={() => handleViewFile(file)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      style={{
                        padding: '8px 16px',
                        background: 'linear-gradient(to right, #10b981, #059669)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      <Eye size={16} /> View
                    </motion.button>
                    <motion.a
                      href={file.url}
                      download
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      style={{
                        padding: '8px 16px',
                        background: 'linear-gradient(to right, #3b82f6, #2563eb)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        textDecoration: 'none',
                        fontSize: '14px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      <Download size={16} /> Download
                    </motion.a>
                    <motion.button
                      onClick={() => handleDeleteFile(file.ref, file.name)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      style={{
                        padding: '8px 16px',
                        background: 'linear-gradient(to right, #ef4444, #dc2626)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      <Trash2 size={16} /> Delete
                    </motion.button>
                  </div>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        )}
      </div>

      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              backgroundColor: 'rgba(0, 0, 0, 0.85)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              zIndex: 1000,
            }}
            onClick={closeModal}
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              style={{
                position: 'relative',
                maxWidth: '90%',
                maxHeight: '90%',
                backgroundColor: 'white',
                borderRadius: '12px',
                overflow: 'hidden',
                boxShadow: '0 8px 24px rgba(0, 0, 0, 0.2)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={selectedImage}
                alt="Preview"
                style={{
                  maxWidth: '100%',
                  maxHeight: '80vh',
                  objectFit: 'contain',
                  borderRadius: '10px',
                }}
              />
              <motion.button
                onClick={closeModal}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                style={{
                  position: 'absolute',
                  top: '12px',
                  right: '12px',
                  padding: '8px',
                  backgroundColor: 'rgba(0, 0, 0, 0.7)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '50%',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <X size={20} />
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: i => ({
    opacity: 1,
    y: 0,
    transition: { delay: 0.13 * i }
  }),
  hover: { scale: 1.06, boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.25)" }
};

const actionVariants = {
  hover: { scale: 1.04, backgroundColor: "#f5f7fa", transition: { duration: 0.2 } },
  tap: { scale: 0.98, backgroundColor: "#eacdff" }
};

const OverviewContent = ({ stats, loading, setActiveTab }) => {
  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading dashboard data...</p>
      </div>
    );
  }

  return (
    <motion.div className="overview-content" initial="hidden" animate="visible">
      <div className="stats-grid">
        {[
          { color: "gradient-blue", icon: "📁", value: stats.totalFiles, label: "Total Files", desc: "All uploaded documents" },
          { color: "gradient-orange", icon: "⏳", value: stats.pendingFiles, label: "Pending Files", desc: "Awaiting processing" },
          { color: "gradient-green", icon: "✅", value: stats.completedFiles, label: "Completed Files", desc: "Processing finished" }
        ].map((item, i) => (
          <motion.div
            className={`stat-card ${item.color}`}
            key={item.label}
            variants={cardVariants}
            custom={i}
            initial="hidden"
            animate="visible"
            whileHover="hover"
          >
            <div className="stat-icon">{item.icon}</div>
            <div className="stat-info">
              <motion.div className="stat-number">{item.value}</motion.div>
              <div className="stat-label">{item.label}</div>
              <div className="stat-detail">{item.desc}</div>
            </div>
          </motion.div>
        ))}
      </div>
      <div className="quick-actions">
        <h3>Quick Actions</h3>
        <div className="action-grid">
          <motion.button
            className="action-card"
            whileHover="hover"
            whileTap="tap"
            variants={actionVariants}
            onClick={() => setActiveTab('files')}
          >
            <div className="action-icon">📤</div>
            <div className="action-content">
              <div className="action-title">Upload Files</div>
              <div className="action-desc">Add new documents</div>
            </div>
          </motion.button>
          <motion.button
            className="action-card"
            whileHover="hover"
            whileTap="tap"
            variants={actionVariants}
            onClick={() => setActiveTab('RecordsView')}
          >
            <div className="action-icon">📋</div>
            <div className="action-content">
              <div className="action-title">View Records</div>
              <div className="action-desc">Browse all files</div>
            </div>
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

  const FileManagementContent = () => {
    return (
      <div className="file-management-content">
        <FileUpload path={`data`} />
      </div>
    );
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <OverviewContent
            stats={stats}
            files={files}
            loading={loading}
            setActiveTab={setActiveTab}
          />
        );
      case 'files':
        return <FileManagementContent />;
      case 'RecordsView':
        return <FileRecordsList stats={stats} />;
      case 'portfolio':
        return <PortfolioContent currentUser={currentUser} />;
      default:
        return (
          <OverviewContent
            stats={stats}
            files={files}
            loading={loading}
            setActiveTab={setActiveTab}
          />
        );
    }
  };

  return (
    <div className="dashboard-container">
      <aside className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-header">
          <div className="logo">
            <span className="logo-icon">👑</span>
            {!sidebarCollapsed && <h2>Admin Panel</h2>}
          </div>
          <button
            className="sidebar-toggle"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            title={sidebarCollapsed ? 'Expand' : 'Collapse'}
          >
            {sidebarCollapsed ? '➡️' : '⬅️'}
          </button>
        </div>
        <nav className="sidebar-nav">
          {menuItems.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
              onClick={() => setActiveTab(item.id)}
              title={sidebarCollapsed ? item.label : ''}
            >
              <span className="nav-icon">{item.icon}</span>
              {!sidebarCollapsed && (
                <span className="nav-label">{item.label}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="user-profile">
            <div className="profile-avatar">
              {currentUser?.email?.charAt(0).toUpperCase()}
            </div>
            {!sidebarCollapsed && (
              <div className="profile-info">
                <span className="profile-name">
                  {currentUser?.email?.split('@')[0]}
                </span>
                <span className="profile-role">Administrator</span>
              </div>
            )}
          </div>
          <button
            onClick={handleLogout}
            className="logout-button"
            title={sidebarCollapsed ? 'Logout' : ''}
          >
            <span>🚪</span>
            {!sidebarCollapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>
      <div className="main-content">
        <header className="top-header">
          <div className="header-left">
            <h1>📊 Dashboard</h1>
            <p>
              Welcome back, <strong>{currentUser?.email?.split('@')[0]}</strong>
            </p>
          </div>
          {/* <div className="header-right">
            <button className="notification-btn" title="Notifications">
              🔔
            </button>
            <button className="search-btn" title="Search">
              🔍
            </button>
          </div> */}
        </header>
        <main className="dashboard-main">{renderContent()}</main>
      </div>
    </div>
  );
};

export default Dashboard;