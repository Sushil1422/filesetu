// src/components/Login.js
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, Link } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, currentUser, userRole } = useAuth();
  const navigate = useNavigate();

  // Watch for role changes after login
  useEffect(() => {
    if (currentUser && userRole) {
      // Role-based navigation
      if (userRole === 'admin') {
        navigate('/dashboard');
      } else if (userRole === 'subadmin') {
        navigate('/subadmin-dashboard');
      }
    }
  }, [currentUser, userRole, navigate]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setError('');
      setLoading(true);
      await login(formData.email, formData.password);
      // Navigation will be handled by useEffect
    } catch (error) {
      setError('Failed to login: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <style>
        {`
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }

          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow: hidden;
          }

          .login-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            position: relative;
            overflow: hidden;
          }

          .login-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: float 20s ease-in-out infinite;
            pointer-events: none;
          }

          @keyframes float {
            0%, 100% { transform: translate(0px, 0px) rotate(0deg); }
            33% { transform: translate(30px, -30px) rotate(120deg); }
            66% { transform: translate(-20px, 20px) rotate(240deg); }
          }

          .login-form {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            padding: 3rem;
            border-radius: 25px;
            box-shadow: 
              0 25px 45px rgba(0, 0, 0, 0.2),
              0 0 0 1px rgba(255, 255, 255, 0.3),
              inset 0 1px 0 rgba(255, 255, 255, 0.4);
            width: 100%;
            max-width: 450px;
            position: relative;
            transform: translateY(0);
            transition: all 0.3s ease;
          }

          .login-form:hover {
            transform: translateY(-5px);
            box-shadow: 
              0 35px 60px rgba(0, 0, 0, 0.25),
              0 0 0 1px rgba(255, 255, 255, 0.3),
              inset 0 1px 0 rgba(255, 255, 255, 0.4);
          }

          .login-form::before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, #667eea, #764ba2, #667eea);
            border-radius: 27px;
            z-index: -1;
            opacity: 0.7;
            filter: blur(10px);
          }

          .login-form h2 {
            text-align: center;
            margin-bottom: 2.5rem;
            color: #2c3e50;
            font-size: 2.2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #dee1efff, #d1b3eeff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            position: relative;
          }

          .login-form h2::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 2px;
            opacity: 0.8;
          }

          .form-group {
            margin-bottom: 1.8rem;
            position: relative;
          }

          .form-group label {
            display: block;
            margin-bottom: 0.75rem;
            font-weight: 600;
            color: #34495e;
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }

          .form-group input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e1e8ed;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: rgba(255, 255, 255, 0.9);
            color: #2c3e50;
            outline: none;
            position: relative;
          }

          .form-group input:focus {
            border-color: #667eea;
            background: white;
            box-shadow: 
              0 0 0 4px rgba(102, 126, 234, 0.1),
              0 8px 25px rgba(102, 126, 234, 0.15);
            transform: translateY(-2px);
          }

          .form-group input::placeholder {
            color: #95a5a6;
            transition: opacity 0.3s ease;
          }

          .form-group input:focus::placeholder {
            opacity: 0.7;
          }

          .login-button {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
          }

          .login-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
          }

          .login-button:hover::before {
            left: 100%;
          }

          .login-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 35px rgba(102, 126, 234, 0.4);
          }

          .login-button:active {
            transform: translateY(-1px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
          }

          .login-button:disabled {
            background: linear-gradient(135deg, #95a5a6, #7f8c8d);
            cursor: not-allowed;
            transform: none;
            box-shadow: 0 4px 15px rgba(149, 165, 166, 0.3);
          }

          .login-button:disabled::before {
            display: none;
          }

          .error-message {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            font-weight: 500;
            box-shadow: 0 8px 25px rgba(231, 76, 60, 0.3);
            animation: slideDown 0.3s ease-out;
            position: relative;
          }

          .error-message::before {
            content: '⚠️';
            margin-right: 10px;
            font-size: 1.1rem;
          }

          @keyframes slideDown {
            from {
              opacity: 0;
              transform: translateY(-20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          .login-link {
            text-align: center;
            margin-top: 2rem;
            color: #7f8c8d;
            font-size: 0.95rem;
            padding-top: 1.5rem;
            border-top: 1px solid rgba(127, 140, 141, 0.2);
          }

          .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
          }

          .login-link a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -2px;
            left: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            transition: all 0.3s ease;
            transform: translateX(-50%);
          }

          .login-link a:hover {
            color: #764ba2;
            transform: translateY(-1px);
          }

          .login-link a:hover::after {
            width: 100%;
          }

          /* Loading Animation */
          @keyframes pulse {
            0% {
              transform: scale(1);
            }
            50% {
              transform: scale(1.05);
            }
            100% {
              transform: scale(1);
            }
          }

          .login-button:disabled {
            animation: pulse 1.5s ease-in-out infinite;
          }

          /* Responsive Design */
          @media (max-width: 768px) {
            .login-container {
              padding: 15px;
            }
            
            .login-form {
              padding: 2rem 1.5rem;
              border-radius: 20px;
            }
            
            .login-form h2 {
              font-size: 1.8rem;
              margin-bottom: 2rem;
            }
            
            .form-group {
              margin-bottom: 1.5rem;
            }
            
            .form-group input {
              padding: 12px 16px;
              font-size: 16px; /* Prevents zoom on iOS */
            }
            
            .login-button {
              padding: 14px;
              font-size: 1rem;
            }
          }

          @media (max-width: 480px) {
            .login-form {
              padding: 1.5rem 1rem;
            }
            
            .login-form h2 {
              font-size: 1.6rem;
            }
          }

          /* Dark mode support */
          @media (prefers-color-scheme: dark) {
            .login-form {
              background: rgba(44, 62, 80, 0.95);
              color: #ecf0f1;
            }
            
            .login-form h2 {
              color: #ecf0f1;
            }
            
            .form-group label {
              color: #bdc3c7;
            }
            
            .form-group input {
              background: rgba(52, 73, 94, 0.8);
              border-color: #34495e;
              color: #ecf0f1;
            }
            
            .form-group input::placeholder {
              color: #7f8c8d;
            }
            
            .login-link {
              color: #95a5a6;
              border-top-color: rgba(149, 165, 166, 0.3);
            }
          }

          /* Accessibility improvements */
          .login-button:focus,
          .form-group input:focus {
            outline: 2px solid #667eea;
            outline-offset: 2px;
          }

          @media (prefers-reduced-motion: reduce) {
            * {
              animation-duration: 0.01ms !important;
              animation-iteration-count: 1 !important;
              transition-duration: 0.01ms !important;
            }
            
            .login-container::before {
              animation: none;
            }
          }

          /* High contrast mode */
          @media (prefers-contrast: high) {
            .login-form {
              background: white;
              border: 2px solid black;
            }
            
            .form-group input {
              border: 2px solid black;
            }
            
            .login-button {
              background: black;
              color: white;
              border: 2px solid black;
            }
          }
        `}
      </style>

      <div className="login-container">
        <div className="login-form">
          <h2>Welcome Back</h2>
          {error && <div className="error-message">{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Email:</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Enter your email"
                required
              />
            </div>

            <div className="form-group">
              <label>Password:</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter your password"
                required
              />
            </div>

            <button type="submit" disabled={loading} className="login-button">
              {loading ? 'Signing In...' : 'Sign In'}
            </button>
          </form>
          
          <p className="login-link">
            Don't have an account? <Link to="/signup">Create Account</Link>
          </p>
        </div>
      </div>
    </>
  );
};

export default Login;
