import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { database } from '../firebase';
import { ref, onValue, remove } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import FileUpload from './FileUpload';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, Pencil, Download, Trash2, X } from 'lucide-react';

const FileRecordsList = () => {
  const { currentUser, userProfile } = useAuth();
  const [records, setRecords] = useState([]);
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [loading, setLoading] = useState(true);
  const [viewRecord, setViewRecord] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredRecords, setFilteredRecords] = useState([]);
  const navigate = useNavigate();
  const [editRecordId, setEditRecordId] = useState(null);
  const [showDashboard, setShowDashboard] = useState(false);
  const [editRecordData, setEditRecordData] = useState(null);

  
  useEffect(() => {
    if (!currentUser) {
      setRecords([]);
      setLoading(false);
      return;
    }
    const dbRef = ref(database, 'data');
    const unsubscribe = onValue(
      dbRef,
      (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const formattedRecords = Object.entries(data).map(([id, value]) => ({
            id,
            ...value,
          }));
          let filteredRecords;
          if (userProfile && userProfile.role === 'admin') {
            filteredRecords = formattedRecords;
          } else {
            filteredRecords = formattedRecords.filter(
              (record) => record.uploadedBy === currentUser.uid
            );
          }
          setRecords(filteredRecords);
        } else {
          setRecords([]);
        }
        setLoading(false);
      },
      (error) => {
        console.error('Error fetching records:', error);
        setLoading(false);
      }
    );
    return () => unsubscribe();
  }, [currentUser, userProfile]);

  useEffect(() => {
    let curr = [...records];
    if (searchTerm.trim() !== '') {
      const t = searchTerm.toLowerCase();
      curr = curr.filter(
        (rec) =>
          (rec.inwardNumber && rec.inwardNumber.toLowerCase().includes(t)) ||
          (rec.allocatedTo && rec.allocatedTo.toLowerCase().includes(t)) ||
          (rec.department && rec.department.toLowerCase().includes(t)) ||
          (rec.inwardDate && rec.inwardDate.toLowerCase().includes(t))
      );
    }
    setFilteredRecords(
      curr.sort((a, b) => {
        let aVal = a[sortBy];
        let bVal = b[sortBy];
        if (sortBy === 'createdAt' || sortBy === 'inwardDate') {
          aVal = Number(aVal) || new Date(aVal).getTime();
          bVal = Number(bVal) || new Date(bVal).getTime();
        } else {
          aVal = (aVal || '').toString().toLowerCase();
          bVal = (bVal || '').toString().toLowerCase();
        }
        if (sortOrder === 'asc') {
          return aVal > bVal ? 1 : aVal < bVal ? -1 : 0;
        } else {
          return aVal < bVal ? 1 : aVal > bVal ? -1 : 0;
        }
      })
    );
  }, [records, searchTerm, sortBy, sortOrder]);

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleView = (rec) => setViewRecord(rec);
  
  const handleEdit = (rec) => {
    setEditRecordId(rec.id);
    setEditRecordData(rec); // Pass the entire record data to the edit form
    setShowDashboard(true);
  };

  const handleDownload = (url) => window.open(url, '_blank');
  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this record? This action cannot be undone.')) {
      remove(ref(database, `data/${id}`))
        .then(() => alert('Record deleted successfully'))
        .catch((error) => alert('Failed to delete record: ' + error.message));
    }
  };

  if (!currentUser) {
    return (
      <div className="records-container">
        <div className="records-header">
          <p>Please log in to view file records.</p>
        </div>
      </div>
    );
  }
  if (loading) {
    return (
      <div className="records-container">
        <div className="records-header">
          <p>Loading records...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <motion.div 
        className="data-table-section"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="records-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h2 style={{ fontWeight: 600, color: '#293049', margin: 0 }}>
            📋 Uploaded Files
          </h2>
          <div>
            <input
              type="search"
              className="records-search"
              placeholder="Search by Inward Number, Allocated To, Department, Inward Date..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <table className="data-table">
          <thead>
            <tr>
              <th>Inward Number</th>
              <th>Inward Date</th>
              <th>Receiving Date</th>
              <th>Department</th>
              <th>Allocated To</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {!filteredRecords.length ? (
              <tr>
                <td colSpan={7} style={{ textAlign: 'center', color: '#aaa' }}>
                  No records.
                </td>
              </tr>
            ) : (
              <AnimatePresence>
                {filteredRecords.map((rec) => (
                  <motion.tr
                    key={rec.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    className={rec.department === 'Public Representation' ? 'highlight-public-rep' : ''}
                    whileHover={{ backgroundColor: '#f9fafb' }}
                  >
                    <td>
                      {/* Show star for Public Representation */}
                      {rec.department === 'Public Representation' && (
                        <span title="Public Representation" style={{ color: '#fbbf24', marginRight: '6px' }}>
                          ★
                        </span>
                      )}
                      {rec.inwardNumber || '-'}
                    </td>
                    <td>{rec.inwardDate || '-'}</td>
                    <td>{rec.receivingDate || '-'}</td>
                    <td>{rec.department || '-'}</td>
                    <td>{rec.allocatedTo || '-'}</td>
                    <td>{rec.status || '-'}</td>
                    <td>
                      <motion.button 
                        onClick={() => handleView(rec)} 
                        title="View"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Eye size={16} />
                      </motion.button>
                      <motion.button 
                        onClick={() => handleEdit(rec)} 
                        title="Edit"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Pencil size={16} />
                      </motion.button>
                      <motion.button 
                        onClick={() => handleDownload(rec.fileURL)} 
                        title="Download"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Download size={16} />
                      </motion.button>
                      <motion.button 
                        onClick={() => handleDelete(rec.id)} 
                        title="Delete" 
                        style={{ color: 'red' }}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Trash2 size={16} />
                      </motion.button>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            )}
          </tbody>
        </table>

        {showDashboard && (
          <AnimatePresence>
            <motion.div
              className="overlay"
              onClick={() => setShowDashboard(false)}
              role="dialog"
              aria-modal="true"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <motion.div
                className="modal-content"
                onClick={(e) => e.stopPropagation()}
                tabIndex={-1}
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.9 }}
                transition={{ duration: 0.3 }}
              >
                <FileUpload 
                  selectedId={editRecordId} 
                  recordData={editRecordData} // Pass the record data to FileUpload
                  onClose={() => setShowDashboard(false)}
                />
              </motion.div>
            </motion.div>
          </AnimatePresence>
        )}

        <style jsx>{`
          .data-table-section {
            max-width: 1200px;
            margin: 2rem auto 0 auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 2px 16px 0 rgba(45, 55, 72, 0.1);
            padding: 2rem 1rem;
          }
          .records-header h2 {
            font-size: 1.4rem;
          }
          .records-search {
            padding: 0.55rem 1.2rem;
            border-radius: 9px;
            border: 1.5px solid #cbd5e1;
            font-size: 1rem;
            width: 320px;
            transition: border 0.18s, box-shadow 0.18s;
            box-sizing: border-box;
          }
          .records-search:focus {
            border: 1.5px solid #667eea;
            box-shadow: 0 0 8px #667eea33;
            outline: none;
          }
          .data-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
          }
          .data-table th,
          .data-table td {
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem 0.7rem;
            font-size: 1rem;
            text-align: left;
          }
          .data-table th {
            background: linear-gradient(
              90deg,
              #667eea 10%,
              #764ba2 85%
            );
            color: #fff;
            font-weight: 600;
            letter-spacing: 0.03em;
            border-bottom: 2px solid #e0e7ef;
          }
          .data-table tr:last-child td {
            border-bottom: none;
          }
          .data-table td button {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1.14rem;
            padding: 4px 7px;
            margin-right: 3px;
            border-radius: 6px;
            transition: background 0.13s;
          }
          .data-table td button:hover {
            background: #f3f4fb;
            color: #6366f1;
          }
          .data-table td button[title='Delete']:hover {
            color: #e53e3e;
            background: #fef2f2;
          }
          .highlight-public-rep {
            background-color: #fffbeb; /* pale yellow highlight */
            font-weight: 600;
          }
          .overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(6px);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
          }
          .modal-content {
            background: white;
            border-radius: 14px;
            max-width: 90vw;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            padding: 1.5rem;
          }
        `}</style>
      </motion.div>

      {/* Modal for viewing file */}
      <AnimatePresence>
        {viewRecord && (
          <motion.div
            className="modal-overlay"
            onClick={() => setViewRecord(null)}
            role="dialog"
            aria-modal="true"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="modal"
              onClick={(e) => e.stopPropagation()}
              tabIndex={-1}
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              transition={{ duration: 0.3 }}
            >
              <h3>
                {viewRecord.fileName || 'File'}{' '}
                <button
                  className="close-btn"
                  onClick={() => setViewRecord(null)}
                  title="Close"
                  aria-label="Close viewer"
                >
                  <X size={20} />
                </button>
              </h3>
              <div className="modal-content">
                {viewRecord.fileType?.startsWith('image/') ? (
                  <img
                    src={viewRecord.fileURL}
                    alt={viewRecord.fileName}
                    style={{
                      maxWidth: '100%',
                      maxHeight: '70vh',
                      borderRadius: '8px',
                    }}
                  />
                ) : viewRecord.fileType === 'application/pdf' ? (
                  <iframe
                    src={viewRecord.fileURL}
                    title={viewRecord.fileName}
                    style={{
                      width: '100%',
                      height: '70vh',
                      border: 'none',
                      borderRadius: '8px',
                    }}
                  />
                ) : (
                  <div>
                    <p style={{ margin: '1em 0', color: '#4b5563' }}>
                      Preview not supported for this file type.
                    </p>
                    <button
                      className="download-btn"
                      onClick={() => handleDownload(viewRecord.fileURL)}
                    >
                      ⬇️ Download File
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
            <style jsx>{`
              .modal-overlay {
                position: fixed;
                inset: 0;
                background: rgba(0, 0, 0, 0.45);
                z-index: 1000;
                display: flex;
                align-items: center;
                justify-content: center;
              }
              .modal {
                background: #fff;
                padding: 2rem;
                border-radius: 14px;
                box-shadow: 0 8px 40px rgba(55, 65, 81, 0.25);
                max-width: 600px;
                width: 94vw;
                max-height: 90vh;
                overflow: auto;
                position: relative;
              }
              .modal h3 {
                font-size: 1.25rem;
                font-weight: 700;
                margin-bottom: 1rem;
                color: #293049;
                display: flex;
                align-items: center;
                justify-content: space-between;
              }
              .close-btn {
                background: none;
                border: none;
                font-size: 1.6rem;
                color: #888;
                cursor: pointer;
                margin-left: 1em;
                transition: color 0.18s;
              }
              .close-btn:hover {
                color: #f56565;
              }
              .modal-content {
                margin-top: 1rem;
                text-align: center;
              }
              .download-btn {
                background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                border: none;
                border-radius: 6px;
                padding: 0.75em 1.3em;
                font-size: 1rem;
                font-weight: 600;
                cursor: pointer;
                margin-top: 1rem;
                transition: background 0.18s;
              }
              .download-btn:hover {
                background: linear-gradient(90deg, #764ba2 20%, #667eea 100%);
              }
            `}</style>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default FileRecordsList;